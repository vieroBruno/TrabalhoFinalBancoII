package repository;

import model.PedidoItem;

public interface PedidoItemRepository {
    void save(PedidoItem pedidoItem);
}